from distutils.core import setup

setup(
	name = "tinyintErrorDavidArteaga",
	packages = ["package"],
	version = "0.1",
	description = "Este paquete nos permite validar errores de tipo tinyInt",
	author = "David Arteaga",
	author_email = "david17art@gmail.com",
	url = "https://github.com/david17art/tinyIntValidate"

)